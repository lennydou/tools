package com.xiaomi.micloud.file.transfer.io;

/**
 * 常量类
 */
interface LiteralConstant {
    String CONTENT_LENGTH = "Content-Length";
}
