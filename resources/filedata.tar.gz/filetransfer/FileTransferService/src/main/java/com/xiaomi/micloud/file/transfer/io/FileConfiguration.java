package com.xiaomi.micloud.file.transfer.io;

/**
 * FileIOUtils的配置信息
 */
class FileConfiguration {
    
}
