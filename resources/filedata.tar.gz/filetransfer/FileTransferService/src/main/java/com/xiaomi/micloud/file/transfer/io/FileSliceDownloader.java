package com.xiaomi.micloud.file.transfer.io;

import org.apache.commons.lang3.Validate;

import java.net.URI;

/**
 * 下载一个文件的某个切片
 */
public class FileSliceDownloader implements Runnable {

    // 该文件切片在所有文件切片中的编号
    private int id;

    // 文件所在的uri
    private URI uri;

    // 文件切片在文件中的起始位置
    private long start;

    // 文件切片在文件中的截止位置
    private long end;

    /**
     * 构造文件切片下载对象
     *
     * @param id    文件切片在该文件所有切片中的编号
     * @param uri   文件切片所属文件的uri
     * @param start 文件切片在所属文件中的起始位置
     * @param end   文件切片在所属文件中的截止位置
     */
    public FileSliceDownloader(int id, URI uri, long start, long end) {
        Validate.notNull(uri);
        Validate.isTrue(start >= 0L);
        Validate.isTrue(end >= 0L);

        this.id = id;
        this.uri = uri;
        this.start = start;
        this.end = end;
    }

    public void run() {

    }
}
