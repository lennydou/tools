package com.xiaomi.micloud.file.transfer.io;

/**
 * 文件处理类.<br/>
 * 该类在FileIOUtils中使用, 当文件下载完成后, 会调用FileHandler实例的handle方法, 并传入文件内容.
 *
 * Note: FileHandler可能在多个线程中共享, 需要是线程安全的.
 */
public interface FileHandler {

    /**
     * 文件下载完成后, 调用handle方法处理文件.
     *
     * @param fileData 文件内容
     */
    void handle(byte[] fileData);
}
