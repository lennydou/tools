package com.xiaomi.micloud.file.transfer.io;

import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 远程文件工具类.
 */
public class FileIOUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(FileIOUtils.class);

    /**
     * 下载文件的线程池
     */
    private static final ExecutorService executorService = Executors.newCachedThreadPool();

    /**
     * 获得url指定文件的length.<br/>
     * 该方法会使用HEAD方法, 获得远程文件的长度.
     *
     * @param uri 文件的url
     * @return    文件长度, 单位是byte
     */
    public static long getFileLength(URI uri) throws IOException {
        Validate.notNull(uri);

        final CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpHead httpGet = new HttpHead(uri);

        long fileLength = 0L;
        try {
            fileLength = httpClient.execute(httpGet, new FileLengthResponseHandler());
        } catch (Throwable e) {
            LOGGER.error("Failed to get file length for {}", uri.toString(), e);
            throw new IOException("Failed to get file length for " + uri.toString());
        } finally {
            httpClient.close();
        }

        return fileLength;
    }

    /**
     * 下载url指定的文件
     *
     */
    public static void download(URI uri, long fileLength, FileHandler fileHandler) {
        Validate.notNull(uri);
        Validate.notNull(fileHandler);
    }

    /**
     * HEAD方法返回对象的处理类, handleResponse方法返回文件长度
     */
    private static class FileLengthResponseHandler implements ResponseHandler<Long> {

        /**
         * 从HttpResponse实例中获取文件长度
         *
         * @param response Http的返回对象
         * @return         Http返回对象中包含的文件长度信息
         */
        public Long handleResponse(HttpResponse response) throws ClientProtocolException, IOException {
            int status = response.getStatusLine().getStatusCode();
            if (status < HttpStatus.SC_OK || status >= HttpStatus.SC_MULTIPLE_CHOICES) {
                throw new ClientProtocolException("Unexpected response status: " + status);
            }

            Header clHeader = response.getFirstHeader(LiteralConstant.CONTENT_LENGTH);
            Validate.notNull(clHeader);

            return NumberUtils.toLong(clHeader.getValue(), 0L);
        }
    }
}
