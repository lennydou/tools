package com.xiaomi.micloud.transfer.file;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.File;
import java.io.IOException;

/**
 * Hello world!
 *
 */
public class BasicProgram {
    private static String PIC_URL = "http://img4.duitang.com/uploads/item/201204/19/20120419112349_uz2CF.jpeg";

    public static void main( String[] args ) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            HttpGet httpGet = new HttpGet(PIC_URL);
            System.out.println("Executing request: " + httpGet.getRequestLine());

            // Create a custom response handler
            final ResponseHandler<byte[]> responseHandler = new ResponseHandler<byte[]>() {
                public byte[] handleResponse(HttpResponse httpResponse) throws ClientProtocolException, IOException {
                    int status = httpResponse.getStatusLine().getStatusCode();
                    if (status >= 200 && status < 300) {
                        HttpEntity entity = httpResponse.getEntity();
                        return entity != null ? EntityUtils.toByteArray(entity) : null;
                    } else {
                        throw new ClientProtocolException("Unexpected response status: " + status);
                    }
                }
            };

            byte[] respBody = httpClient.execute(httpGet, responseHandler);
            System.out.println("size: " + respBody.length);
            FileUtils.writeByteArrayToFile(new File("/home/dyl/temp/test.jpg"), respBody);

        } finally {
            httpClient.close();
        }

        System.out.println("Completed!!");
    }
}
