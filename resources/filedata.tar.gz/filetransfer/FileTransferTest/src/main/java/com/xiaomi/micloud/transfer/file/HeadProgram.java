package com.xiaomi.micloud.transfer.file;

import org.apache.http.Header;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import java.io.IOException;

/**
 * 获得文件长度
 */
public class HeadProgram {
    private static String PIC_URL = "http://img4.duitang.com/uploads/item/201204/19/20120419112349_uz2CF.jpeg";

    public static void main( String[] args ) throws IOException {
        final CloseableHttpClient httpClient = HttpClients.createDefault();
        try {
            HttpHead httpGet = new HttpHead(PIC_URL);

            System.out.println("Executing request: " + httpGet.getRequestLine());
            HeaderIterator iter = httpGet.headerIterator();
            while (iter.hasNext()) {
                Header header = iter.nextHeader();
                System.out.println(header.getName() + ": " + header.getValue());
            }

            // Create a custom response handler
            final ResponseHandler<Long> responseHandler = new ResponseHandler<Long>() {
                public Long handleResponse(HttpResponse httpResponse) throws IOException {
                    int status = httpResponse.getStatusLine().getStatusCode();
                    if (status < 200 || status >= 300) {
                        throw new ClientProtocolException("Unexpected response status: " + status);
                    }

                    System.out.println(httpResponse.getHeaders("Content-Length").length);
                    System.out.println(httpResponse.getHeaders("Content-Length")[0].getValue());

                    return 0L;
                }
            };

            long fileLength = httpClient.execute(httpGet, responseHandler);
            System.out.println("fileSize: " + fileLength);

        } finally {
            httpClient.close();
        }

        System.out.println("Completed!!");
    }
}
